import OrdersPage from "../presentation/OrdersPage";


const OrdersPageContainer = () => {
    return (
        <OrdersPage />
    )
}

export default OrdersPageContainer;