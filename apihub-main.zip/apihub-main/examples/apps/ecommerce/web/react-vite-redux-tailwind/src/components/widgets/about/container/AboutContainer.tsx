import About from "../presentation/About"


const AboutContainer = () => {
    return (
        <About />
    )
}

export default AboutContainer;