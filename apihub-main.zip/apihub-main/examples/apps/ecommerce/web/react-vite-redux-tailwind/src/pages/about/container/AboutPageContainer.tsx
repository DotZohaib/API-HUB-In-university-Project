import AboutPage from "../presentation/AboutPage";


const AboutPageContainer = () => {
    return (
        <AboutPage />
    )
}

export default AboutPageContainer;