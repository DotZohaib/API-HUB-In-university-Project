import AboutContainer from "../../../components/widgets/about/container/AboutContainer";


const AboutPage = () => {
    return (
        <div>
            <AboutContainer />
        </div>
    )
}

export default AboutPage;